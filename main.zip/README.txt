============================================
AI智能考试系统 v4.0
============================================

============================================
[中文]
============================================

## 项目概述
AI智能考试系统是一个基于 Web 的在线考试平台，支持教师管理、学生考试、自动判分等功能。
适用于 Windows Server + Nginx 部署环境。

技术栈：Python Flask + SQLite + openpyxl + HTML/CSS/JS

## 使用说明

### 部署
1. 将 `backend/` 和 `frontend/` 部署到 `C:\Program Files\TESTsys\Files\`
2. 从 `backend/` 目录运行 `pip install -r requirements.txt`
3. 配置 Nginx（参考 `nginx-testsys-server.conf`）
4. 运行 `start.bat` 启动后端
5. 浏览器访问 http://localhost

### 教师账号
- 内置教师：登录ID=001，密码=123
- 教师注册：在登录页点击"教师注册"创建新账号

### 使用流程
1. 教师登录 → 下载模板 → 上传试卷模板 → 上传学生信息 → 考试设置
2. 学生登录 → 选择考试 → 开始答题 → 提交试卷
3. 教师查看成绩 → 手动批改简答题

## 目录结构
```
C:\Program Files\TESTsys\
└── Files\
    ├── frontend\          # 前端HTML页面
    │   ├── login.html          # 首页(双按钮入口)
    │   ├── teacher-login.html  # 教师登录
    │   ├── student-login.html  # 学生登录(含编号+Stata)
    │   ├── exam-cover.html     # 考试封面(含开考时间控制)
    │   ├── exam.html           # 在线考试
    │   ├── grading.html        # 阅卷系统
    │   ├── exam-setup.html     # 考试设置
    │   ├── teacher.html        # 教师管理
    │   ├── monitor.html        # 监视面板
    │   └── register.html       # 教师注册
    ├── backend\            # Flask后端
    │   ├── app.py
    │   ├── .env
    │   ├── requirements.txt
    │   └── testsys.db
    ├── Users\              # 用户存储
    │   └── <用户名>\        # 每用户一个文件夹
    │       └── <试卷名>\     # 每试卷一个子文件夹
    │           └── attachments\  # 试卷附件
    └── start.bat           # 启动脚本
```

## 版本历史
| 版本 | 日期 | 说明 |
|------|------|------|
| v1.0 | 2026-05-04 | 初始版本 |
| v2.0 | 2026-05-05 | 防作弊/监视/Stata/AI |
| v3.0 | 2026-05-06 | 题目开关/附件/设置/部署 |
| v3.1 | 2026-05-06 | 注册/用户目录/哈希/限制 |
| v3.2 | 2026-05-07 | .env/附件路径/start.bat |
| v3.3 | 2026-05-07 | 修复/美化/测试完成 |

============================================
[English]
============================================

## Project Overview
AI Smart Examination System is a web-based online exam platform supporting teacher management, student examination, and auto-grading. Designed for Windows Server with Nginx reverse proxy.

Tech Stack: Python Flask + SQLite + openpyxl + HTML/CSS/JS

## How to Use

### Deployment
1. Deploy `backend/` and `frontend/` to `C:\Program Files\TESTsys\Files\`
2. Run `pip install -r requirements.txt` from `backend/`
3. Configure Nginx (see `nginx-testsys-server.conf`)
4. Run `start.bat` to start backend
5. Open http://localhost in browser

### Teacher Accounts
- Built-in teacher: ID=001, password=123
- Registration: click "教师注册" on login page

### Workflow
1. Teacher login → Download template → Upload exam template → Upload student info → Exam settings
2. Student login → Select exam → Start answering → Submit
3. Teacher review grades → Manual grading for essay questions

## Directory Structure
```
C:\Program Files\TESTsys\
└── Files\
    ├── frontend\          # HTML pages
    ├── backend\           # Flask backend
    ├── Users\             # User data storage
    └── start.bat          # Startup script
```

## Version History
| Version | Date | Description |
|---------|------|-------------|
| v1.0 | 2026-05-04 | Initial version |
| v2.0 | 2026-05-05 | Anti-cheat/monitor/Stata/AI |
| v3.0 | 2026-05-06 | Question switches/attachments/settings |
| v3.1 | 2026-05-06 | Registration/user dir/hash/limits |
| v3.2 | 2026-05-07 | .env/attachment path/start.bat |
| v3.3 | 2026-05-07 | Bug fixes/UI beautification/tested |
